# cable_1123 > 2022-11-29 5:06pm
https://universe.roboflow.com/yuanshung/cable_1123

Provided by a Roboflow user
License: CC BY 4.0

